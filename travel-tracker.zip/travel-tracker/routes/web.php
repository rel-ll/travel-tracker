<?php

use App\Http\Controllers\TravelController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn() => redirect()->route('travels.index'));

Route::resource('travels', TravelController::class);
