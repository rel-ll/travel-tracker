<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Travel Tracker')</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f4f8;
            color: #2d3748;
            min-height: 100vh;
        }

        /* ── NAV ─────────────────────────────────────────── */
        nav {
            background: linear-gradient(135deg, #1a365d 0%, #2b6cb0 100%);
            color: white;
            padding: 0 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 60px;
            box-shadow: 0 2px 8px rgba(0,0,0,.25);
            position: sticky; top: 0; z-index: 100;
        }
        .nav-brand { font-size: 1.2rem; font-weight: 700; letter-spacing: .5px; text-decoration: none; color: white; }
        .nav-brand span { opacity: .7; font-weight: 400; font-size: .95rem; }
        .nav-link {
            color: rgba(255,255,255,.85); text-decoration: none;
            padding: .4rem .9rem; border-radius: 6px; font-size: .9rem;
            transition: background .2s;
        }
        .nav-link:hover { background: rgba(255,255,255,.15); }

        /* ── CONTAINER ───────────────────────────────────── */
        .container { max-width: 1100px; margin: 0 auto; padding: 2rem 1rem; }

        /* ── ALERTS ──────────────────────────────────────── */
        .alert {
            padding: .85rem 1.2rem; border-radius: 8px; margin-bottom: 1.2rem;
            font-size: .92rem; border-left: 4px solid;
        }
        .alert-success { background: #f0fff4; border-color: #48bb78; color: #276749; }
        .alert-error   { background: #fff5f5; border-color: #fc8181; color: #9b2c2c; }

        /* ── CARDS ───────────────────────────────────────── */
        .card {
            background: white; border-radius: 12px;
            box-shadow: 0 1px 4px rgba(0,0,0,.08), 0 4px 16px rgba(0,0,0,.06);
            overflow: hidden;
        }
        .card-header {
            padding: 1.2rem 1.5rem;
            border-bottom: 1px solid #e2e8f0;
            display: flex; align-items: center; justify-content: space-between;
            background: #f7fafc;
        }
        .card-header h2 { font-size: 1.1rem; font-weight: 600; color: #2d3748; }
        .card-body { padding: 1.5rem; }

        /* ── STATS ROW ───────────────────────────────────── */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .stat-card {
            background: white; border-radius: 10px;
            padding: 1rem 1.2rem;
            box-shadow: 0 1px 4px rgba(0,0,0,.08);
            text-align: center;
        }
        .stat-card .stat-icon { font-size: 1.8rem; margin-bottom: .3rem; }
        .stat-card .stat-value { font-size: 1.4rem; font-weight: 700; color: #2b6cb0; }
        .stat-card .stat-label { font-size: .78rem; color: #718096; text-transform: uppercase; letter-spacing: .5px; }

        /* ── TABLE ───────────────────────────────────────── */
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: .9rem; }
        th {
            padding: .75rem 1rem; text-align: left; font-size: .78rem;
            text-transform: uppercase; letter-spacing: .5px; color: #718096;
            border-bottom: 2px solid #e2e8f0; background: #f7fafc;
        }
        td { padding: .75rem 1rem; border-bottom: 1px solid #edf2f7; vertical-align: middle; }
        tr:hover td { background: #f7fafc; }

        /* ── MODE BADGES ─────────────────────────────────── */
        .badge {
            display: inline-flex; align-items: center; gap: .3rem;
            padding: .25rem .65rem; border-radius: 99px;
            font-size: .78rem; font-weight: 600;
        }
        .badge-air  { background: #ebf8ff; color: #2b6cb0; }
        .badge-sea  { background: #e6fffa; color: #276749; }
        .badge-land { background: #fffbeb; color: #975a16; }

        /* ── BUTTONS ─────────────────────────────────────── */
        .btn {
            display: inline-flex; align-items: center; gap: .4rem;
            padding: .5rem 1.1rem; border-radius: 7px; font-size: .88rem;
            font-weight: 500; cursor: pointer; border: none; text-decoration: none;
            transition: opacity .15s, transform .1s;
        }
        .btn:hover { opacity: .88; transform: translateY(-1px); }
        .btn:active { transform: translateY(0); }
        .btn-primary  { background: #2b6cb0; color: white; }
        .btn-success  { background: #38a169; color: white; }
        .btn-warning  { background: #d69e2e; color: white; }
        .btn-danger   { background: #e53e3e; color: white; }
        .btn-outline  {
            background: transparent; border: 1.5px solid #cbd5e0; color: #4a5568;
        }
        .btn-sm { padding: .3rem .75rem; font-size: .82rem; }

        /* ── FORM ────────────────────────────────────────── */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.2rem;
        }
        .form-group { display: flex; flex-direction: column; gap: .4rem; }
        .form-group.full { grid-column: 1 / -1; }
        label { font-size: .85rem; font-weight: 600; color: #4a5568; }
        label .req { color: #e53e3e; }
        input, select, textarea {
            padding: .55rem .85rem; border: 1.5px solid #e2e8f0;
            border-radius: 7px; font-size: .92rem; color: #2d3748;
            background: white; transition: border-color .2s;
            width: 100%;
        }
        input:focus, select:focus, textarea:focus {
            outline: none; border-color: #2b6cb0;
            box-shadow: 0 0 0 3px rgba(43,108,176,.12);
        }
        .error { color: #e53e3e; font-size: .8rem; margin-top: .2rem; }

        /* Mode selector cards */
        .mode-selector { display: flex; gap: 1rem; flex-wrap: wrap; }
        .mode-option { display: none; }
        .mode-label {
            display: flex; flex-direction: column; align-items: center;
            gap: .4rem; padding: .9rem 1.4rem; border: 2px solid #e2e8f0;
            border-radius: 10px; cursor: pointer; transition: all .2s;
            min-width: 90px; background: white;
        }
        .mode-label .mode-icon { font-size: 1.6rem; }
        .mode-label .mode-text { font-size: .8rem; font-weight: 600; color: #718096; }
        .mode-option:checked + .mode-label {
            border-color: #2b6cb0; background: #ebf8ff; color: #2b6cb0;
        }
        .mode-option:checked + .mode-label .mode-text { color: #2b6cb0; }

        /* ── PAGE HEADER ─────────────────────────────────── */
        .page-header {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 1.5rem;
        }
        .page-header h1 { font-size: 1.5rem; font-weight: 700; color: #1a365d; }

        /* ── FILTER BAR ──────────────────────────────────── */
        .filter-bar {
            display: flex; gap: .75rem; flex-wrap: wrap;
            align-items: flex-end; margin-bottom: 1.2rem;
        }
        .filter-bar input, .filter-bar select {
            width: auto; min-width: 140px;
        }

        /* ── DETAIL VIEW ─────────────────────────────────── */
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        .detail-item { }
        .detail-label { font-size: .78rem; text-transform: uppercase; letter-spacing: .5px; color: #718096; margin-bottom: .25rem; }
        .detail-value { font-size: 1rem; font-weight: 600; color: #2d3748; }

        .route-display {
            display: flex; align-items: center; gap: .75rem;
            font-size: 1.2rem; font-weight: 700; color: #1a365d;
            padding: 1rem; background: #ebf8ff; border-radius: 10px;
            margin-bottom: 1.5rem;
        }
        .route-arrow { color: #2b6cb0; font-size: 1.5rem; }

        /* ── PAGINATION ──────────────────────────────────── */
        .pagination { display: flex; gap: .5rem; margin-top: 1rem; }
        .pagination a, .pagination span {
            padding: .4rem .8rem; border-radius: 6px; font-size: .88rem;
            border: 1px solid #e2e8f0; text-decoration: none; color: #4a5568;
        }
        .pagination .active { background: #2b6cb0; color: white; border-color: #2b6cb0; }
        .pagination a:hover { background: #f7fafc; }

        @media (max-width: 600px) {
            .stats-row { grid-template-columns: repeat(2, 1fr); }
            .page-header { flex-direction: column; align-items: flex-start; gap: .75rem; }
        }
    </style>
</head>
<body>

<nav>
    <a href="{{ route('travels.index') }}" class="nav-brand">
        🗺️ Travel Tracker <span>/ Records</span>
    </a>
    <a href="{{ route('travels.create') }}" class="nav-link">+ New Travel</a>
</nav>

<div class="container">

    @if(session('success'))
        <div class="alert alert-success">✅ {{ session('success') }}</div>
    @endif

    @if($errors->any())
        <div class="alert alert-error">
            <strong>Please fix the following:</strong>
            <ul style="margin-top:.5rem;padding-left:1.2rem">
                @foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach
            </ul>
        </div>
    @endif

    @yield('content')
</div>

</body>
</html>
