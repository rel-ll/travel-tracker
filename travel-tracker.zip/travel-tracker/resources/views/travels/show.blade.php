@extends('layouts.app')
@section('title', 'Travel #' . $travel->id)

@section('content')

<div class="page-header">
    <h1>Travel Record #{{ $travel->id }}</h1>
    <div style="display:flex;gap:.75rem;flex-wrap:wrap">
        <a href="{{ route('travels.edit', $travel) }}" class="btn btn-warning">✏️ Edit</a>
        <form method="POST" action="{{ route('travels.destroy', $travel) }}"
              onsubmit="return confirm('Delete this record permanently?')">
            @csrf @method('DELETE')
            <button class="btn btn-danger">🗑 Delete</button>
        </form>
        <a href="{{ route('travels.index') }}" class="btn btn-outline">← Back to List</a>
    </div>
</div>

<div class="card">
    <div class="card-body">

        {{-- ROUTE BANNER --}}
        <div class="route-display">
            <span>{{ $travel->mode_icon }}</span>
            <span>{{ $travel->origin }}</span>
            <span class="route-arrow">→</span>
            <span>{{ $travel->destination }}</span>
            <span class="badge badge-{{ $travel->travel_mode }}" style="margin-left:auto">
                {{ $travel->mode_label }}
            </span>
        </div>

        <div class="detail-grid">
            <div class="detail-item">
                <div class="detail-label">Purpose / Project</div>
                <div class="detail-value">{{ $travel->purpose }}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Travel Date</div>
                <div class="detail-value">{{ $travel->travel_date->format('F d, Y') }}</div>
            </div>
            @if($travel->return_date)
            <div class="detail-item">
                <div class="detail-label">Return Date</div>
                <div class="detail-value">{{ $travel->return_date->format('F d, Y') }}</div>
            </div>
            @endif
            <div class="detail-item">
                <div class="detail-label">Passengers</div>
                <div class="detail-value">👥 {{ $travel->passengers }} person(s)</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Total Amount</div>
                <div class="detail-value" style="color:#2b6cb0;font-size:1.25rem">
                    {{ $travel->formatted_amount }}
                </div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Itinerary File</div>
                <div class="detail-value">
                    @if($travel->itinerary_path)
                        <a href="{{ Storage::url($travel->itinerary_path) }}" target="_blank" class="btn btn-outline btn-sm">
                            📎 Download Itinerary
                        </a>
                    @else
                        <span style="color:#a0aec0">No file uploaded</span>
                    @endif
                </div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Created</div>
                <div class="detail-value" style="font-size:.9rem;font-weight:400;color:#718096">
                    {{ $travel->created_at->format('M d, Y H:i') }}
                </div>
            </div>
        </div>

        @if($travel->notes)
            <div style="margin-top:1.5rem;padding:1rem;background:#f7fafc;border-radius:8px;border-left:3px solid #cbd5e0">
                <div class="detail-label" style="margin-bottom:.5rem">Notes</div>
                <p style="color:#4a5568;line-height:1.6">{{ $travel->notes }}</p>
            </div>
        @endif

    </div>
</div>

@endsection
